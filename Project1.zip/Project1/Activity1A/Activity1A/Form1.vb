﻿Public Class Form1

    Private Sub DisplayBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisplayBtn.Click

        'Declare and Initialize Variable "Sum" as Integer and store a value of 0
        Dim Sum As Integer = 0

        'Delare variable "EndNumber"
        Dim EndNumber As Integer


        'Get the Value of "EndNoTextBox" and store it to "EndNumber" Variable
        EndNumber = EndNoTextBox.Text

        'Add the numbers from 1 up to "EndNumber" and Store them to "Sum"
        For i As Integer = 1 To EndNumber
            Sum = Sum + i
        Next

        'Display "Sum" to SumTextBox
        SumTextBox.Text = Sum

        'Clear Listbox1
        ListBox1.Items.Clear()

        'Get the State of the Checkboxes and if the status is "Checked" then add them to Listbox1
        If FoodChkBox.CheckState = CheckState.Checked Then
            ListBox1.Items.Add(FoodChkBox.Text)
        End If

        If MovieChkBox.CheckState = CheckState.Checked Then
            ListBox1.Items.Add(MovieChkBox.Text)
        End If

        If SportsChkBox.CheckState = CheckState.Checked Then
            ListBox1.Items.Add(SportsChkBox.Text)
        End If

        If SMChkBox.CheckState = CheckState.Checked Then
            ListBox1.Items.Add(SMChkBox.Text)
        End If


    End Sub

    Private Sub ClearBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearBtn.Click
        SumTextBox.Clear()      'Clear SumTextBox
        ListBox1.Items.Clear()  'Clear ListBox1
        EndNoTextBox.Clear()    'Clear EndNoTextBox


    End Sub

End Class
