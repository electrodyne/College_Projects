﻿Public Class Form1

    'An array of 10 elements
    Dim SkipCountingArray(9) As Integer

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        'Declare skipValue as Integer
        Dim skipValue As Integer

        'Declare sum as Integer and set an initial value of 0
        Dim sum As Integer = 0

        'set the value of TextBox1 to skipValue
        skipValue = TextBox1.Text

        'Added, Clear the list box
        ListBox1.Items.Clear()

        For i As Integer = 0 To 9

            'store the "skipValue" to SkipCountArray @ i
            SkipCountingArray(i) = skipValue

            'Add the "Current Value" of skipValue to the Listbox via SkipCountArray
            ListBox1.Items.Add(SkipCountingArray(i))

            'Add the skipValue to the Sum variable
            sum = sum + skipValue

            'Update SkipValue by increasing it's value by "SkipValue" fetched from the TextBox1
            skipValue = skipValue + TextBox1.Text
        Next

        'Display the sum to TextBox2
        TextBox2.Text = sum
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Clear()        'Clear Textbox1
        TextBox2.Clear()        'Clear Textbox2
        ListBox1.Items.Clear()  'Clear Listbox1
    End Sub

End Class
