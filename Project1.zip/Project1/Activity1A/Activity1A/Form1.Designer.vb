﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.EndNoTextBox = New System.Windows.Forms.TextBox()
        Me.SumTextBox = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.FoodChkBox = New System.Windows.Forms.CheckBox()
        Me.MovieChkBox = New System.Windows.Forms.CheckBox()
        Me.SportsChkBox = New System.Windows.Forms.CheckBox()
        Me.SMChkBox = New System.Windows.Forms.CheckBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.DisplayBtn = New System.Windows.Forms.Button()
        Me.ClearBtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(207, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Complete Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(129, 24)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "End Number"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 88)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 24)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Sum"
        '
        'EndNoTextBox
        '
        Me.EndNoTextBox.Location = New System.Drawing.Point(161, 54)
        Me.EndNoTextBox.Name = "EndNoTextBox"
        Me.EndNoTextBox.Size = New System.Drawing.Size(109, 20)
        Me.EndNoTextBox.TabIndex = 3
        '
        'SumTextBox
        '
        Me.SumTextBox.Location = New System.Drawing.Point(161, 92)
        Me.SumTextBox.Name = "SumTextBox"
        Me.SumTextBox.ReadOnly = True
        Me.SumTextBox.Size = New System.Drawing.Size(109, 20)
        Me.SumTextBox.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 135)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(128, 24)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "My Favorites"
        '
        'FoodChkBox
        '
        Me.FoodChkBox.AutoSize = True
        Me.FoodChkBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FoodChkBox.Location = New System.Drawing.Point(64, 172)
        Me.FoodChkBox.Name = "FoodChkBox"
        Me.FoodChkBox.Size = New System.Drawing.Size(62, 22)
        Me.FoodChkBox.TabIndex = 6
        Me.FoodChkBox.Text = "Food"
        Me.FoodChkBox.UseVisualStyleBackColor = True
        '
        'MovieChkBox
        '
        Me.MovieChkBox.AutoSize = True
        Me.MovieChkBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MovieChkBox.Location = New System.Drawing.Point(64, 195)
        Me.MovieChkBox.Name = "MovieChkBox"
        Me.MovieChkBox.Size = New System.Drawing.Size(67, 22)
        Me.MovieChkBox.TabIndex = 7
        Me.MovieChkBox.Text = "Movie"
        Me.MovieChkBox.UseVisualStyleBackColor = True
        '
        'SportsChkBox
        '
        Me.SportsChkBox.AutoSize = True
        Me.SportsChkBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SportsChkBox.Location = New System.Drawing.Point(64, 218)
        Me.SportsChkBox.Name = "SportsChkBox"
        Me.SportsChkBox.Size = New System.Drawing.Size(71, 22)
        Me.SportsChkBox.TabIndex = 8
        Me.SportsChkBox.Text = "Sports"
        Me.SportsChkBox.UseVisualStyleBackColor = True
        '
        'SMChkBox
        '
        Me.SMChkBox.AutoSize = True
        Me.SMChkBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SMChkBox.Location = New System.Drawing.Point(64, 241)
        Me.SMChkBox.Name = "SMChkBox"
        Me.SMChkBox.Size = New System.Drawing.Size(112, 22)
        Me.SMChkBox.TabIndex = 9
        Me.SMChkBox.Text = "Social Media"
        Me.SMChkBox.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 18
        Me.ListBox1.Location = New System.Drawing.Point(332, 54)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(218, 202)
        Me.ListBox1.TabIndex = 10
        '
        'DisplayBtn
        '
        Me.DisplayBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DisplayBtn.Location = New System.Drawing.Point(332, 275)
        Me.DisplayBtn.Name = "DisplayBtn"
        Me.DisplayBtn.Size = New System.Drawing.Size(100, 44)
        Me.DisplayBtn.TabIndex = 11
        Me.DisplayBtn.Text = "DISPLAY"
        Me.DisplayBtn.UseVisualStyleBackColor = True
        '
        'ClearBtn
        '
        Me.ClearBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearBtn.Location = New System.Drawing.Point(450, 275)
        Me.ClearBtn.Name = "ClearBtn"
        Me.ClearBtn.Size = New System.Drawing.Size(100, 44)
        Me.ClearBtn.TabIndex = 12
        Me.ClearBtn.Text = "CLEAR"
        Me.ClearBtn.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(562, 358)
        Me.Controls.Add(Me.ClearBtn)
        Me.Controls.Add(Me.DisplayBtn)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.SMChkBox)
        Me.Controls.Add(Me.SportsChkBox)
        Me.Controls.Add(Me.MovieChkBox)
        Me.Controls.Add(Me.FoodChkBox)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.SumTextBox)
        Me.Controls.Add(Me.EndNoTextBox)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents EndNoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SumTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents FoodChkBox As System.Windows.Forms.CheckBox
    Friend WithEvents MovieChkBox As System.Windows.Forms.CheckBox
    Friend WithEvents SportsChkBox As System.Windows.Forms.CheckBox
    Friend WithEvents SMChkBox As System.Windows.Forms.CheckBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents DisplayBtn As System.Windows.Forms.Button
    Friend WithEvents ClearBtn As System.Windows.Forms.Button

End Class
